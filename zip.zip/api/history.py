import json
import os
from http.server import BaseHTTPRequestHandler
from urllib.parse import parse_qs, urlparse

from sqlalchemy import create_engine, Column, Integer, String, Float, DateTime
from sqlalchemy.orm import declarative_base, sessionmaker
from datetime import datetime

# ── DB SETUP ──
db_file = "/tmp/prices.db"
engine = create_engine(f"sqlite:///{db_file}", connect_args={"check_same_thread": False})
Base = declarative_base()

class PriceHistory(Base):
    __tablename__ = "price_history"
    id    = Column(Integer, primary_key=True)
    query = Column(String(200))
    title = Column(String(500))
    price = Column(Float)
    site  = Column(String(100))
    date  = Column(DateTime, default=datetime.utcnow)

Base.metadata.create_all(engine)
Session = sessionmaker(bind=engine)

API_KEY = os.environ.get("SERPAPI_KEY", "")


class handler(BaseHTTPRequestHandler):
    def do_GET(self):
        parsed = urlparse(self.path)
        params = parse_qs(parsed.query)
        query  = params.get("q",     [None])[0]
        title  = params.get("title", [None])[0]

        if not API_KEY:
            self._respond(500, {"error": "SERPAPI_KEY not set in Vercel environment variables."})
            return

        if not query or not title:
            self._respond(400, {"error": "Missing ?q= or &title= parameter"})
            return

        session = Session()
        records = (
            session.query(PriceHistory)
            .filter(PriceHistory.query == query.lower())
            .filter(PriceHistory.title == title)
            .order_by(PriceHistory.date.asc())
            .all()
        )
        session.close()

        history_data = [
            {
                "date":  r.date.strftime("%d %b %Y %H:%M"),
                "price": r.price,
                "site":  r.site,
            }
            for r in records
        ]
        self._respond(200, history_data)

    def _respond(self, status, body):
        payload = json.dumps(body).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def log_message(self, format, *args):
        pass
