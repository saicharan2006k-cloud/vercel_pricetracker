import json
import os
from http.server import BaseHTTPRequestHandler
from urllib.parse import parse_qs, urlparse

from serpapi import GoogleSearch
from sqlalchemy import create_engine, Column, Integer, String, Float, DateTime
from sqlalchemy.orm import declarative_base, sessionmaker
from datetime import datetime

# ── DB SETUP (Vercel uses /tmp for writable storage) ──
db_file = "/tmp/prices.db"
engine = create_engine(f"sqlite:///{db_file}", connect_args={"check_same_thread": False})
Base = declarative_base()

class PriceHistory(Base):
    __tablename__ = "price_history"
    id    = Column(Integer, primary_key=True)
    query = Column(String(200))
    title = Column(String(500))
    price = Column(Float)
    site  = Column(String(100))
    date  = Column(DateTime, default=datetime.utcnow)

Base.metadata.create_all(engine)
Session = sessionmaker(bind=engine)

API_KEY = os.environ.get("SERPAPI_KEY", "")


def parse_price(price_str):
    try:
        return float(price_str.replace("₹", "").replace(",", "").strip())
    except Exception:
        return None


def get_direct_link(p):
    sources = p.get("multiple_sources", [])
    if isinstance(sources, list) and len(sources) > 0:
        direct = sources[0].get("link", "")
        if direct:
            return direct
    return p.get("product_link", "#") or "#"


def get_products(query):
    params = {
        "engine": "google_shopping",
        "q": query,
        "gl": "in",
        "hl": "en",
        "api_key": API_KEY,
    }
    search = GoogleSearch(params)
    results = search.get_dict()
    products = results.get("shopping_results", [])

    session = Session()
    final = []
    for p in products[:12]:
        title     = p.get("title", "N/A")
        price_str = p.get("price", "N/A")
        site      = p.get("source", "N/A")
        image     = p.get("thumbnail", "")
        link      = get_direct_link(p)
        rating    = p.get("rating", None)
        reviews   = p.get("reviews", None)
        price_val = parse_price(price_str)

        if price_val and title != "N/A":
            record = PriceHistory(
                query=query.lower(),
                title=title,
                price=price_val,
                site=site,
            )
            session.add(record)

        final.append({
            "title": title, "price": price_str, "site": site,
            "image": image, "link": link, "rating": rating, "reviews": reviews,
        })

    session.commit()
    session.close()
    return final


class handler(BaseHTTPRequestHandler):
    def do_GET(self):
        parsed = urlparse(self.path)
        params = parse_qs(parsed.query)
        query  = params.get("q", [None])[0]

        if not API_KEY:
            self._respond(500, {"error": "SERPAPI_KEY not set in Vercel environment variables."})
            return

        if not query:
            self._respond(400, {"error": "Missing ?q= parameter"})
            return

        try:
            data = get_products(query)
            self._respond(200, data)
        except Exception as e:
            self._respond(500, {"error": str(e)})

    def _respond(self, status, body):
        payload = json.dumps(body).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def log_message(self, format, *args):
        pass  # silence default access logs
